const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const componentsDir = './components';
let allCSS = '';
let allJS = '';

const components = fs.readdirSync(componentsDir);

components.forEach(name => {
  const dir = path.join(componentsDir, name);
  if (!fs.statSync(dir).isDirectory()) return;

  const cssFile = path.join(dir, `${name}.css`);
  const jsFile  = path.join(dir, `${name}.js`);

  if (fs.existsSync(cssFile)) {
    allCSS += `/* === ${name} === */\n` + fs.readFileSync(cssFile, 'utf8') + '\n\n';
    console.log(`✅ CSS: ${name}`);
  }

  if (fs.existsSync(jsFile)) {
    allJS += `/* === ${name} === */\n` + fs.readFileSync(jsFile, 'utf8') + '\n\n';
    console.log(`✅ JS: ${name}`);
  }
});

fs.mkdirSync('./dist', { recursive: true });

// Write full versions
fs.writeFileSync('./dist/components.css', allCSS);
fs.writeFileSync('./dist/components.js', allJS);
console.log('\n📦 Full files written');

// Minify CSS → components.min.css
fs.writeFileSync('./dist/components.min.css', '');
execSync('npx --yes clean-css-cli ./dist/components.css -o ./dist/components.min.css');
console.log('🗜️  CSS minified → dist/components.min.css');

// Minify JS → components.min.js
execSync('npx --yes terser ./dist/components.js -o ./dist/components.min.js --compress --mangle');
console.log('🗜️  JS minified  → dist/components.min.js');

console.log('\n🎉 Build complete!');
console.log('   dist/components.css');
console.log('   dist/components.js');
console.log('   dist/components.min.css  ← use this in production');
console.log('   dist/components.min.js   ← use this in production');